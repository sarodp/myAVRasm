/*******************************************       
Project : AVR-p20 led flash
Version : 1
Date    : 15.09.2003 �.
Author  : 
Company : OLIMEX LTD
Comments: http://www.olimex.com/dev 

Chip type           : AT90S2313
Clock frequency     : 10,000000 MHz
Memory model        : Tiny
Internal SRAM size  : 128
External SRAM size  : 0
Data Stack size     : 32
*********************************************/

#include <90s2313.h>
#include <delay.h>
#include <stdio.h>

#define	LED		PORTB.7
#define BUT		PIND.2

void main(void)
{

// Input/Output Ports initialization
// Port B
PORTB=0x00;
DDRB=0x80;

// Port D
PORTD=0x04;
DDRD=0x00;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
// Mode: Output Compare
// OC0 output: Disconnected
TCCR0=0x00;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer 1 Stopped
// Mode: Output Compare
// OC1 output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
OCR1H=0x00;
OCR1L=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
GIMSK=0x00;
MCUCR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;

while (1)
      {
      	LED = !LED;				//toggle LED
	delay_ms(200);      	
	while (BUT == 0) LED = 0; 
      }
}
