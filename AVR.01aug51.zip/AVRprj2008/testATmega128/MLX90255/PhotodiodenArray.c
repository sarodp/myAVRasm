
#include <p18f242.h>
#include <delays.h>
#include <adc.h>


#define     SI	    	PORTBbits.RB0
#define     CLK			PORTBbits.RB1

											//					  __
#define     DELAY		Delay10TCYx(3)		// 2 �s --> 16 �s |__|	|



// ---------------------------------------------------------------------------------
void putcUSART(char data)
	{
	 if(TXSTAbits.TX9) TXSTAbits.TX9D = 0;          // 9-bit mode? Set the TX9D bit according to the
	 while(!TXSTAbits.TRMT);                        //
	 TXREG = data;                                  // Write the data byte to the USART
	}
// ---------------------------------------------------------------------------------
char getcUSART(void)
	{
  	char data;                        	// Holds received data
  	unsigned char i=0;
	
	if(RCSTAbits.OERR||RCSTAbits.FERR) 	// Error ?
        {
        RCSTA = 0;
        RCSTA = 0x90; 
        } 

  	while((!PIR1bits.RCIF)&&(++i<255)){ClrWdt();};   //Wait for data to be received      

  	if(PIR1bits.RCIF) data = RCREG;     // Read data 
	else data = 0x00;

  	return data;                        // Return the received data
	}
// ---------------------------------------------------------------------------------v
void putINT(unsigned int zahl)
	{
   unsigned int zw;
   char i=0;

    zw=zahl/10000;
    if(0!=zw|i)
        {
        putcUSART(zw+0x30);
        i = 1;
        }

    zahl=zahl-zw*10000;	
    zw=zahl/1000;
	if(0!=zw|i)
        {
        putcUSART(zw+0x30);
        i = 1;
        }

    zahl=zahl-zw*1000;	
    zw=zahl/100;
	if(0!=zw|i)
        {
        putcUSART(zw+0x30);
        i = 1;
        }

	zahl=zahl-zw*100;		
	zw=zahl/10;
	if(0!=zw|i)
        {
        putcUSART(zw+0x30);
        i = 1;
        }
	       
	zahl=zahl-zw*10;		
	putcUSART(zahl+0x30);
	}
// ---------------------------------------------------------------------------------
void ReadPixel(void)
	{
	ConvertADC(); // Start conversion
	putcUSART(';');

	while( BusyADC() ); // Wait for completion
	putINT(ReadADC());	
	}
// ---------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------





void main (void)
 {
 unsigned int i;
 int data[32];
// Init ------------------------------------------------------------------

 SPBRG = 15;                    // 15 --> 19200 Baud @ 4,9152MHz
 TXSTA = 0b00000000;            // Register zur�cksetzen (funktioniert so am besten)        
 RCSTA = 0b00000000;
 TXSTA = 0b10100100;            // TXEN enabled, BRGH High Speed, Asynchronus Mode        
 RCSTA = 0b10010000;            // SPEN enabled, CREN enabled

 DDRCbits.RC6 = 0;              // Tx
 DDRCbits.RC7 = 1;              // Rx

 TRISB = 0b00000000;         	// SI / CLK --> Output
 SI  = 0;
 CLK = 1;

 OpenADC( ADC_FOSC_32 & ADC_RIGHT_JUST & ADC_8ANA_0REF, ADC_CH0 & ADC_INT_OFF );
// Programm --------------------------------------------------------------


 while(1)
    {

	if(getcUSART()=='S')
		{
	    putcUSART('S');
	    putcUSART('T');
	    putcUSART('A');
	    putcUSART('R');
	    putcUSART('T');
		CLK = 0;
		DELAY;
		SI = 1;
		DELAY;
		CLK = 1;
		DELAY;
		SI = 0;
		DELAY;
		CLK = 0;
		// ReadPixel();			// Pixel 1
		DELAY;
		DELAY;

		for(i=0;i<131;i++)		// Pixel 2 - 132
			{
			CLK = 1;
			DELAY;
			DELAY;
			CLK = 0;
			// ReadPixel();
			DELAY;
			DELAY;
			}

		CLK = 1;
		DELAY;
		DELAY;
		CLK = 0;				// Pixel 133
		DELAY;
		DELAY;
		CLK = 1;

// Auslesen -------------------------------------------------------------


		CLK = 0;
		DELAY;
		SI = 1;
		DELAY;
		CLK = 1;
		DELAY;
		SI = 0;
		DELAY;
		CLK = 0;
		// ReadPixel();			// Pixel 1
		DELAY;
		DELAY;

		for(i=0;i<131;i++)		// Pixel 2 - 132
			{
			CLK = 1;
			DELAY;
			DELAY;
			CLK = 0;
			ReadPixel();
			DELAY;
			DELAY;
			}

		CLK = 1;
		DELAY;
		DELAY;
		CLK = 0;				// Pixel 133
		DELAY;
		DELAY;
		CLK = 1;





		putcUSART(0x0d);		// CR LF
	    putcUSART(0x0a);
		} 




    }
 }


