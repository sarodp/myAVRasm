AVR Development Tools version 1.04

Welcome to the AVR Development Tools version 1.04.
Please note that a number of changes have been made
in the instruction set since the May 1996 Data Book.
The new instructions are all available in this
version of the Development Tools.

The new instructions are:

        ADIW:   Add Immediate to Word
        CBI:    Clear Bit in I/O
        LDS:    Load Direct
        SBI:    Set Bit in I/O
        SBIC:   Skip if Bit in I/O cleared
        SBIS:   Skip if Bit in I/O set
        SBIW:   Subtract Immediate from Word
        STS:    Store Direct

For a more detailed description on these instructions,
see the on-line help, or the Atmel Data-Books CD-ROM
covering microcontrollers, November 1996 edition or later.
